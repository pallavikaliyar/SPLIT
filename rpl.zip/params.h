//Set options field to good or bad
char cnodetwo[33] = "11111111111111111111111111111111";

//Set Reserved field to good or bad
char rnodetwo[3] = "11";
