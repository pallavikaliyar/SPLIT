place files 
	rpl-icmp6.c and params.h
  of this zip file at path 
	/home/user/contiki/core/net/rpl
