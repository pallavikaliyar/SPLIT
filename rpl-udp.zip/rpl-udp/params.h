//Set options field to good or bad
char cnode[33] = "11111111111111111111111111111111";

//Set Reserved field to good or bad
char rnode[3] = "11";
