//Max number of good nodes.
int good_upperLimit = 3;

//Max number of bad nodes. Bad nodes are after good nodes.
int bad_upperLimit = 6;

